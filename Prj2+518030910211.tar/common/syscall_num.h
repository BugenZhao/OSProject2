/* macro of syscall numbers */

#ifndef _BZ_SYSCALL_NUM_H
#define _BZ_SYSCALL_NUM_H

#define __NR_mm_limit 381
#define __NR_mm_limit_time 382
#define __NR_get_mm_limit 383

#endif /* _BZ_SYSCALL_NUM_H */
